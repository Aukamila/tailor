import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { CustomerOrders } from '../components/CustomerOrders';
import { CustomerMeasurements } from '../components/CustomerMeasurements';
import { CustomerProfile } from '../components/CustomerProfile';
import { 
  User, 
  Package, 
  Ruler, 
  LogOut, 
  Scissors 
} from 'lucide-react';

export function CustomerPortal() {
  const [activeTab, setActiveTab] = useState('orders');
  const { logout, user } = useAuth();

  const handleLogout = async () => {
    await logout();
  };

  const tabs = [
    { id: 'orders', label: 'My Orders', icon: Package },
    { id: 'measurements', label: 'Measurements', icon: Ruler },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Scissors className="h-8 w-8 text-amber-600 mr-3" />
              <h1 className="text-xl font-bold text-gray-900">Customer Portal</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                Welcome, {user?.email}
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center text-gray-600 hover:text-red-600 transition-colors"
              >
                <LogOut className="h-5 w-5 mr-1" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <nav className="bg-white rounded-xl shadow-sm p-6">
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-4 py-3 rounded-lg font-medium transition-colors ${
                        activeTab === tab.id
                          ? 'bg-amber-600 text-white'
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      <Icon className="h-5 w-5 mr-3" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <div className="bg-white rounded-xl shadow-sm">
              {activeTab === 'orders' && <CustomerOrders />}
              {activeTab === 'measurements' && <CustomerMeasurements />}
              {activeTab === 'profile' && <CustomerProfile />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}