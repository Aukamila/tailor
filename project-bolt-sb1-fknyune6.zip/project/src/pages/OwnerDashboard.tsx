import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { CustomerList } from '../components/CustomerList';
import { AddCustomer } from '../components/AddCustomer';
import { OrderManagement } from '../components/OrderManagement';
import { Analytics } from '../components/Analytics';
import { 
  Users, 
  Plus, 
  Package, 
  BarChart3, 
  LogOut, 
  Scissors,
  Search,
  Calendar,
  Settings
} from 'lucide-react';

export function OwnerDashboard() {
  const [activeTab, setActiveTab] = useState('customers');
  const { logout, user } = useAuth();

  const handleLogout = async () => {
    await logout();
  };

  const tabs = [
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'add-customer', label: 'Add Customer', icon: Plus },
    { id: 'orders', label: 'Orders', icon: Package },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Scissors className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-xl font-bold text-gray-900">Master Tailor Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                Welcome, {user?.email}
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center text-gray-600 hover:text-red-600 transition-colors"
              >
                <LogOut className="h-5 w-5 mr-1" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <nav className="bg-white rounded-xl shadow-sm p-6">
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-4 py-3 rounded-lg font-medium transition-colors ${
                        activeTab === tab.id
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      <Icon className="h-5 w-5 mr-3" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <div className="bg-white rounded-xl shadow-sm">
              {activeTab === 'customers' && <CustomerList />}
              {activeTab === 'add-customer' && <AddCustomer />}
              {activeTab === 'orders' && <OrderManagement />}
              {activeTab === 'analytics' && <Analytics />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}