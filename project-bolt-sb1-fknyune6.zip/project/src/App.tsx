import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { OwnerDashboard } from './pages/OwnerDashboard';
import { CustomerPortal } from './pages/CustomerPortal';
import { CustomerLogin } from './pages/CustomerLogin';
import { ProtectedRoute } from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/customer-login" element={<CustomerLogin />} />
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <OwnerDashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/customer-portal" 
              element={
                <ProtectedRoute>
                  <CustomerPortal />
                </ProtectedRoute>
              } 
            />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;