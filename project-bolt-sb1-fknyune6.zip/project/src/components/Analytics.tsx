import React from 'react';
import { BarChart3, TrendingUp, DollarSign, Users, Package, Calendar } from 'lucide-react';

export function Analytics() {
  const monthlyData = [
    { month: 'Jan', revenue: 8500, orders: 12, customers: 8 },
    { month: 'Feb', revenue: 12300, orders: 18, customers: 14 },
    { month: 'Mar', revenue: 9800, orders: 14, customers: 11 },
    { month: 'Apr', revenue: 15600, orders: 22, customers: 17 },
    { month: 'May', revenue: 18200, orders: 26, customers: 20 },
    { month: 'Jun', revenue: 21400, orders: 31, customers: 24 }
  ];

  const totalRevenue = monthlyData.reduce((sum, month) => sum + month.revenue, 0);
  const totalOrders = monthlyData.reduce((sum, month) => sum + month.orders, 0);
  const totalCustomers = monthlyData.reduce((sum, month) => sum + month.customers, 0);

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Analytics Dashboard</h2>
        <p className="text-gray-600">Track your business performance and growth</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">Total Revenue</p>
              <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
              <p className="text-blue-100 text-sm">+15% from last period</p>
            </div>
            <div className="bg-white/20 p-3 rounded-full">
              <DollarSign className="h-6 w-6" />
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">Total Orders</p>
              <p className="text-2xl font-bold">{totalOrders}</p>
              <p className="text-green-100 text-sm">+22% from last period</p>
            </div>
            <div className="bg-white/20 p-3 rounded-full">
              <Package className="h-6 w-6" />
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">New Customers</p>
              <p className="text-2xl font-bold">{totalCustomers}</p>
              <p className="text-purple-100 text-sm">+18% from last period</p>
            </div>
            <div className="bg-white/20 p-3 rounded-full">
              <Users className="h-6 w-6" />
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-100 text-sm">Avg Order Value</p>
              <p className="text-2xl font-bold">${(totalRevenue / totalOrders).toFixed(0)}</p>
              <p className="text-amber-100 text-sm">+8% from last period</p>
            </div>
            <div className="bg-white/20 p-3 rounded-full">
              <TrendingUp className="h-6 w-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Revenue Chart */}
        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
            Monthly Revenue
          </h3>
          <div className="space-y-4">
            {monthlyData.map((month, index) => (
              <div key={month.month} className="flex items-center">
                <div className="w-12 text-sm font-medium text-gray-600">
                  {month.month}
                </div>
                <div className="flex-1 mx-4">
                  <div className="bg-gray-200 rounded-full h-4 relative">
                    <div 
                      className="bg-blue-600 h-4 rounded-full transition-all duration-500"
                      style={{ width: `${(month.revenue / Math.max(...monthlyData.map(m => m.revenue))) * 100}%` }}
                    />
                  </div>
                </div>
                <div className="w-20 text-sm font-medium text-gray-900 text-right">
                  ${month.revenue.toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Orders Chart */}
        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Package className="h-5 w-5 mr-2 text-green-600" />
            Monthly Orders
          </h3>
          <div className="space-y-4">
            {monthlyData.map((month, index) => (
              <div key={month.month} className="flex items-center">
                <div className="w-12 text-sm font-medium text-gray-600">
                  {month.month}
                </div>
                <div className="flex-1 mx-4">
                  <div className="bg-gray-200 rounded-full h-4 relative">
                    <div 
                      className="bg-green-600 h-4 rounded-full transition-all duration-500"
                      style={{ width: `${(month.orders / Math.max(...monthlyData.map(m => m.orders))) * 100}%` }}
                    />
                  </div>
                </div>
                <div className="w-20 text-sm font-medium text-gray-900 text-right">
                  {month.orders} orders
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Garment Types</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Business Suits</span>
              <span className="font-semibold text-gray-900">45%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Evening Dresses</span>
              <span className="font-semibold text-gray-900">28%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Casual Wear</span>
              <span className="font-semibold text-gray-900">18%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Formal Wear</span>
              <span className="font-semibold text-gray-900">9%</span>
            </div>
          </div>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Satisfaction</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Excellent</span>
              <span className="font-semibold text-green-600">78%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Good</span>
              <span className="font-semibold text-blue-600">18%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Average</span>
              <span className="font-semibold text-yellow-600">3%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Poor</span>
              <span className="font-semibold text-red-600">1%</span>
            </div>
          </div>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Status</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Completed</span>
              <span className="font-semibold text-green-600">68%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">In Progress</span>
              <span className="font-semibold text-blue-600">25%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Pending</span>
              <span className="font-semibold text-yellow-600">6%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Cancelled</span>
              <span className="font-semibold text-red-600">1%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}