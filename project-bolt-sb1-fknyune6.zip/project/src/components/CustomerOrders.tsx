import React, { useState } from 'react';
import { Package, Clock, CheckCircle, Calendar, DollarSign, FileText } from 'lucide-react';

interface Order {
  id: string;
  garmentType: string;
  orderDate: string;
  dueDate: string;
  status: 'pending' | 'measuring' | 'cutting' | 'sewing' | 'fitting' | 'completed' | 'cancelled';
  price: number;
  notes: string;
  progress: number;
}

export function CustomerOrders() {
  const [orders] = useState<Order[]>([
    {
      id: 'ORD-001',
      garmentType: 'Business Suit',
      orderDate: '2024-01-15',
      dueDate: '2024-02-15',
      status: 'sewing',
      price: 899.99,
      notes: 'Navy blue, slim fit, peak lapels',
      progress: 70
    },
    {
      id: 'ORD-002',
      garmentType: 'Evening Dress',
      orderDate: '2024-01-20',
      dueDate: '2024-02-20',
      status: 'fitting',
      price: 1299.99,
      notes: 'Red silk, floor length, custom embroidery',
      progress: 85
    },
    {
      id: 'ORD-003',
      garmentType: 'Casual Blazer',
      orderDate: '2024-01-25',
      dueDate: '2024-02-25',
      status: 'completed',
      price: 599.99,
      notes: 'Charcoal gray, modern fit',
      progress: 100
    }
  ]);

  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-800',
    measuring: 'bg-blue-100 text-blue-800',
    cutting: 'bg-orange-100 text-orange-800',
    sewing: 'bg-purple-100 text-purple-800',
    fitting: 'bg-indigo-100 text-indigo-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800'
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'cancelled':
        return <CheckCircle className="h-5 w-5 text-red-600" />;
      default:
        return <Clock className="h-5 w-5 text-blue-600" />;
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">My Orders</h2>
        <p className="text-gray-600">Track your custom garment orders and their progress</p>
      </div>

      {/* Order Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">Total Orders</p>
              <p className="text-2xl font-bold">{orders.length}</p>
            </div>
            <Package className="h-8 w-8 text-blue-100" />
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-100 text-sm">In Progress</p>
              <p className="text-2xl font-bold">
                {orders.filter(o => !['completed', 'cancelled'].includes(o.status)).length}
              </p>
            </div>
            <Clock className="h-8 w-8 text-amber-100" />
          </div>
        </div>
        
        <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">Completed</p>
              <p className="text-2xl font-bold">
                {orders.filter(o => o.status === 'completed').length}
              </p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-100" />
          </div>
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-6">
        {orders.map((order) => (
          <div key={order.id} className="bg-white border rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-blue-50 rounded-full">
                  {getStatusIcon(order.status)}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{order.garmentType}</h3>
                  <p className="text-sm text-gray-600">Order #{order.id}</p>
                </div>
              </div>
              <div className="mt-4 lg:mt-0 flex flex-col lg:flex-row lg:items-center space-y-2 lg:space-y-0 lg:space-x-4">
                <span className={`inline-flex px-3 py-1 text-sm font-medium rounded-full ${statusColors[order.status]}`}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </span>
                <span className="text-lg font-bold text-gray-900">${order.price.toFixed(2)}</span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Progress</span>
                <span>{order.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${order.progress}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <Calendar className="h-4 w-4 mr-2" />
                Order Date: {new Date(order.orderDate).toLocaleDateString()}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Calendar className="h-4 w-4 mr-2" />
                Due Date: {new Date(order.dueDate).toLocaleDateString()}
              </div>
            </div>

            {order.notes && (
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-start">
                  <FileText className="h-4 w-4 text-gray-400 mr-2 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-700">Order Notes</p>
                    <p className="text-sm text-gray-600">{order.notes}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-2">
              <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-colors">
                View Details
              </button>
              {order.status !== 'completed' && (
                <button className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded-lg font-medium transition-colors">
                  Contact Tailor
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}