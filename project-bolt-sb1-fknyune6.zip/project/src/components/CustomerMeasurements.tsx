import React, { useState } from 'react';
import { Ruler, Calendar, TrendingUp, Download } from 'lucide-react';

interface Measurement {
  id: string;
  date: string;
  chest: number;
  waist: number;
  hip: number;
  shoulder: number;
  armLength: number;
  inseam: number;
  neck: number;
  thigh: number;
  tailor: string;
  notes: string;
}

export function CustomerMeasurements() {
  const [measurements] = useState<Measurement[]>([
    {
      id: '1',
      date: '2024-01-15',
      chest: 42,
      waist: 34,
      hip: 40,
      shoulder: 18,
      armLength: 32,
      inseam: 30,
      neck: 16,
      thigh: 24,
      tailor: 'Master John',
      notes: 'Initial measurements for business suit'
    },
    {
      id: '2',
      date: '2024-02-01',
      chest: 41.5,
      waist: 33.5,
      hip: 39.5,
      shoulder: 18,
      armLength: 32,
      inseam: 30,
      neck: 16,
      thigh: 23.5,
      tailor: 'Master John',
      notes: 'Updated measurements after weight loss'
    },
    {
      id: '3',
      date: '2024-02-15',
      chest: 41,
      waist: 33,
      hip: 39,
      shoulder: 18,
      armLength: 32,
      inseam: 30,
      neck: 16,
      thigh: 23,
      tailor: 'Master John',
      notes: 'Final measurements for evening dress'
    }
  ]);

  const measurementFields = [
    { key: 'chest', label: 'Chest', unit: 'inches' },
    { key: 'waist', label: 'Waist', unit: 'inches' },
    { key: 'hip', label: 'Hip', unit: 'inches' },
    { key: 'shoulder', label: 'Shoulder', unit: 'inches' },
    { key: 'armLength', label: 'Arm Length', unit: 'inches' },
    { key: 'inseam', label: 'Inseam', unit: 'inches' },
    { key: 'neck', label: 'Neck', unit: 'inches' },
    { key: 'thigh', label: 'Thigh', unit: 'inches' }
  ];

  const latestMeasurement = measurements[measurements.length - 1];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">My Measurements</h2>
        <p className="text-gray-600">Track your body measurements and their changes over time</p>
      </div>

      {/* Latest Measurements Summary */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl mb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Ruler className="h-8 w-8 mr-3" />
            <div>
              <h3 className="text-xl font-bold">Latest Measurements</h3>
              <p className="text-blue-100">
                Taken on {new Date(latestMeasurement.date).toLocaleDateString()}
              </p>
            </div>
          </div>
          <button className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Download
          </button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {measurementFields.map((field) => (
            <div key={field.key} className="bg-white/10 p-4 rounded-lg">
              <p className="text-blue-100 text-sm">{field.label}</p>
              <p className="text-xl font-bold">
                {latestMeasurement[field.key as keyof Measurement]} {field.unit}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Measurement History */}
      <div className="bg-white border rounded-xl p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
          Measurement History
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 font-medium text-gray-700">Date</th>
                {measurementFields.map((field) => (
                  <th key={field.key} className="text-left py-3 px-4 font-medium text-gray-700">
                    {field.label}
                  </th>
                ))}
                <th className="text-left py-3 px-4 font-medium text-gray-700">Tailor</th>
              </tr>
            </thead>
            <tbody>
              {measurements.map((measurement, index) => (
                <tr key={measurement.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">
                    {new Date(measurement.date).toLocaleDateString()}
                  </td>
                  {measurementFields.map((field) => (
                    <td key={field.key} className="py-3 px-4 text-gray-700">
                      {measurement[field.key as keyof Measurement]}
                    </td>
                  ))}
                  <td className="py-3 px-4 text-gray-700">{measurement.tailor}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Measurement Trends */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Chest Measurements</h3>
          <div className="space-y-3">
            {measurements.map((measurement, index) => (
              <div key={measurement.id} className="flex items-center justify-between">
                <span className="text-sm text-gray-600">
                  {new Date(measurement.date).toLocaleDateString()}
                </span>
                <div className="flex items-center">
                  <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                    <div 
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(measurement.chest / 50) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-12">
                    {measurement.chest}"
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Waist Measurements</h3>
          <div className="space-y-3">
            {measurements.map((measurement, index) => (
              <div key={measurement.id} className="flex items-center justify-between">
                <span className="text-sm text-gray-600">
                  {new Date(measurement.date).toLocaleDateString()}
                </span>
                <div className="flex items-center">
                  <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                    <div 
                      className="bg-green-600 h-2 rounded-full"
                      style={{ width: `${(measurement.waist / 40) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-12">
                    {measurement.waist}"
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}