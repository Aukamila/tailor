import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, Calendar, Save, Plus, AlertCircle, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export function AddCustomer() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    birthDate: '',
    notes: '',
    jobNumber: '',
    requestDate: new Date().toISOString().split('T')[0]
  });

  const [measurements, setMeasurements] = useState({
    // Basic measurements
    height: '',
    neckWidth: '',
    shoulder: '',
    armholeCurveUpperarmWidth: '',
    chest: '',
    underBustNippleToNipple: '',
    waist: '',
    hips: '',
    waistToKneeLength: '',
    waistToAnkle: '',
    thighCirc: '',
    ankleCirc: '',
    shoulderToWaist: '',
    shoulderToAnkle: '',
    shoulderToWrist: '',
    shoulderToElbow: '',
    innerArmLength: '',
    outseamLength: '',
    inseamLength: '',
    backRise: '',
    frontRise: '',
    
    // Additional detailed measurements
    singleShoulder: '',
    frontDrop: '',
    backDrop: '',
    armholeCurveStraight: '',
    neckBandWidth: '',
    collerWidth: '',
    collerPoint: '',
    sleeveLength: '',
    sleeveOppen: '',
    cuffHeight: '',
    waistBand: '',
    legOppen: '',
    seatLength: ''
  });

  const convertMeasurementsForDB = (measurements: any) => {
    return {
      height: measurements.height ? parseFloat(measurements.height) : null,
      neck_width: measurements.neckWidth ? parseFloat(measurements.neckWidth) : null,
      shoulder: measurements.shoulder ? parseFloat(measurements.shoulder) : null,
      armhole_curve_upperarm_width: measurements.armholeCurveUpperarmWidth ? parseFloat(measurements.armholeCurveUpperarmWidth) : null,
      chest: measurements.chest ? parseFloat(measurements.chest) : null,
      underbust_nipple_to_nipple: measurements.underBustNippleToNipple ? parseFloat(measurements.underBustNippleToNipple) : null,
      waist: measurements.waist ? parseFloat(measurements.waist) : null,
      hips: measurements.hips ? parseFloat(measurements.hips) : null,
      waist_to_knee_length: measurements.waistToKneeLength ? parseFloat(measurements.waistToKneeLength) : null,
      waist_to_ankle: measurements.waistToAnkle ? parseFloat(measurements.waistToAnkle) : null,
      thigh_circ: measurements.thighCirc ? parseFloat(measurements.thighCirc) : null,
      ankle_circ: measurements.ankleCirc ? parseFloat(measurements.ankleCirc) : null,
      shoulder_to_waist: measurements.shoulderToWaist ? parseFloat(measurements.shoulderToWaist) : null,
      shoulder_to_ankle: measurements.shoulderToAnkle ? parseFloat(measurements.shoulderToAnkle) : null,
      shoulder_to_wrist: measurements.shoulderToWrist ? parseFloat(measurements.shoulderToWrist) : null,
      shoulder_to_elbow: measurements.shoulderToElbow ? parseFloat(measurements.shoulderToElbow) : null,
      inner_arm_length: measurements.innerArmLength ? parseFloat(measurements.innerArmLength) : null,
      outseam_length: measurements.outseamLength ? parseFloat(measurements.outseamLength) : null,
      inseam_length: measurements.inseamLength ? parseFloat(measurements.inseamLength) : null,
      back_rise: measurements.backRise ? parseFloat(measurements.backRise) : null,
      front_rise: measurements.frontRise ? parseFloat(measurements.frontRise) : null,
      single_shoulder: measurements.singleShoulder ? parseFloat(measurements.singleShoulder) : null,
      front_drop: measurements.frontDrop ? parseFloat(measurements.frontDrop) : null,
      back_drop: measurements.backDrop ? parseFloat(measurements.backDrop) : null,
      armhole_curve_straight: measurements.armholeCurveStraight ? parseFloat(measurements.armholeCurveStraight) : null,
      neck_band_width: measurements.neckBandWidth ? parseFloat(measurements.neckBandWidth) : null,
      collar_width: measurements.collerWidth ? parseFloat(measurements.collerWidth) : null,
      collar_point: measurements.collerPoint ? parseFloat(measurements.collerPoint) : null,
      sleeve_length: measurements.sleeveLength ? parseFloat(measurements.sleeveLength) : null,
      sleeve_opening: measurements.sleeveOppen ? parseFloat(measurements.sleeveOppen) : null,
      cuff_height: measurements.cuffHeight ? parseFloat(measurements.cuffHeight) : null,
      waist_band: measurements.waistBand ? parseFloat(measurements.waistBand) : null,
      leg_opening: measurements.legOppen ? parseFloat(measurements.legOppen) : null,
      seat_length: measurements.seatLength ? parseFloat(measurements.seatLength) : null,
      tailor_name: user?.user_metadata?.ownerName || 'Master Tailor',
      measurement_notes: 'Initial measurements'
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    setLoading(true);

    try {
      console.log('Starting save process...');
      console.log('User:', user);
      console.log('Form data:', formData);

      if (!user) {
        throw new Error('You must be logged in to add customers');
      }

      // Test Supabase connection first
      console.log('Testing Supabase connection...');
      const { data: testData, error: testError } = await supabase
        .from('customers')
        .select('count')
        .limit(1);
      
      if (testError) {
        console.error('Supabase connection test failed:', testError);
        throw new Error(`Database connection failed: ${testError.message}`);
      }
      
      console.log('Supabase connection successful');

      // Validate required fields
      if (!formData.name.trim()) {
        throw new Error('Customer name is required');
      }
      if (!formData.email.trim()) {
        throw new Error('Email address is required');
      }
      if (!formData.phone.trim()) {
        throw new Error('Phone number is required');
      }

      // Insert customer data
      const customerData = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        address: formData.address.trim() || null,
        birth_date: formData.birthDate || null,
        job_number: formData.jobNumber.trim() || null,
        request_date: formData.requestDate || null,
        notes: formData.notes.trim() || null,
        owner_id: user.id
      };

      console.log('Inserting customer data:', customerData);

      const { data: customer, error: customerError } = await supabase
        .from('customers')
        .insert([customerData])
        .select()
        .single();

      if (customerError) {
        console.error('Customer insert error:', customerError);
        throw new Error(`Failed to save customer: ${customerError.message}`);
      }

      console.log('Customer saved successfully:', customer);

      // Insert measurements if any are provided
      const hasAnyMeasurement = Object.values(measurements).some(value => value !== '');
      
      if (hasAnyMeasurement && customer) {
        console.log('Saving measurements...');
        const measurementData = {
          customer_id: customer.id,
          ...convertMeasurementsForDB(measurements)
        };

        console.log('Measurement data:', measurementData);

        const { error: measurementError } = await supabase
          .from('measurements')
          .insert([measurementData]);

        if (measurementError) {
          console.error('Measurement insert error:', measurementError);
          throw new Error(`Failed to save measurements: ${measurementError.message}`);
        }

        console.log('Measurements saved successfully');
      }

      setSuccess(true);
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        address: '',
        birthDate: '',
        notes: '',
        jobNumber: '',
        requestDate: new Date().toISOString().split('T')[0]
      });
      
      setMeasurements({
        height: '', neckWidth: '', shoulder: '', armholeCurveUpperarmWidth: '',
        chest: '', underBustNippleToNipple: '', waist: '', hips: '',
        waistToKneeLength: '', waistToAnkle: '', thighCirc: '', ankleCirc: '',
        shoulderToWaist: '', shoulderToAnkle: '', shoulderToWrist: '', shoulderToElbow: '',
        innerArmLength: '', outseamLength: '', inseamLength: '', backRise: '', frontRise: '',
        singleShoulder: '', frontDrop: '', backDrop: '', armholeCurveStraight: '',
        neckBandWidth: '', collerWidth: '', collerPoint: '', sleeveLength: '',
        sleeveOppen: '', cuffHeight: '', waistBand: '', legOppen: '', seatLength: ''
      });

      console.log('Save process completed successfully');

    } catch (err: any) {
      console.error('Save customer error:', err);
      setError(err.message || 'Failed to save customer data');
    } finally {
      setLoading(false);
    }
  };

  const measurementSections = [
    {
      title: 'Basic Body Measurements',
      fields: [
        { key: 'height', label: 'Height' },
        { key: 'neckWidth', label: 'Neck Width' },
        { key: 'shoulder', label: 'Shoulder' },
        { key: 'armholeCurveUpperarmWidth', label: 'Armhole Curve Upperarm Width' },
        { key: 'chest', label: 'Chest' },
        { key: 'underBustNippleToNipple', label: 'Underbust Nipple to Nipple' },
        { key: 'waist', label: 'Waist' },
        { key: 'hips', label: 'Hips' }
      ]
    },
    {
      title: 'Length Measurements',
      fields: [
        { key: 'waistToKneeLength', label: 'Waist to Knee Length' },
        { key: 'waistToAnkle', label: 'Waist to Ankle' },
        { key: 'shoulderToWaist', label: 'Shoulder to Waist' },
        { key: 'shoulderToAnkle', label: 'Shoulder to Ankle' },
        { key: 'shoulderToWrist', label: 'Shoulder to Wrist' },
        { key: 'shoulderToElbow', label: 'Shoulder to Elbow' },
        { key: 'innerArmLength', label: 'Inner Arm Length' },
        { key: 'outseamLength', label: 'Outseam Length' },
        { key: 'inseamLength', label: 'Inseam Length' }
      ]
    },
    {
      title: 'Circumference Measurements',
      fields: [
        { key: 'thighCirc', label: 'Thigh Circumference' },
        { key: 'ankleCirc', label: 'Ankle Circumference' }
      ]
    },
    {
      title: 'Garment Specific Measurements',
      fields: [
        { key: 'singleShoulder', label: 'Single Shoulder' },
        { key: 'frontDrop', label: 'Front Drop' },
        { key: 'backDrop', label: 'Back Drop' },
        { key: 'armholeCurveStraight', label: 'Armhole Curve Straight' },
        { key: 'neckBandWidth', label: 'Neck Band Width' },
        { key: 'collerWidth', label: 'Collar Width' },
        { key: 'collerPoint', label: 'Collar Point' },
        { key: 'sleeveLength', label: 'Sleeve Length' },
        { key: 'sleeveOppen', label: 'Sleeve Opening' },
        { key: 'cuffHeight', label: 'Cuff Height' },
        { key: 'waistBand', label: 'Waist Band' },
        { key: 'legOppen', label: 'Leg Opening' },
        { key: 'seatLength', label: 'Seat Length' },
        { key: 'backRise', label: 'Back Rise' },
        { key: 'frontRise', label: 'Front Rise' }
      ]
    }
  ];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Add New Customer</h2>
        <p className="text-gray-600">Create a new customer profile with comprehensive measurements</p>
      </div>

      {/* Success Message */}
      {success && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
            <span className="text-green-700 font-medium">Customer and measurements saved successfully!</span>
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-red-600 mr-2 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <span className="text-red-700 font-medium">Error saving customer data:</span>
              <p className="text-red-600 text-sm mt-1">{error}</p>
              <p className="text-red-500 text-xs mt-2">
                Please check the browser console for more details and ensure you're connected to Supabase.
              </p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Customer Information */}
        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <User className="h-5 w-5 mr-2 text-blue-600" />
            Customer Information
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Customer Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter customer name"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Job Number
              </label>
              <input
                type="text"
                value={formData.jobNumber}
                onChange={(e) => setFormData({...formData, jobNumber: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter job number"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address *
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="customer@example.com"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contact Number *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="+1 (555) 123-4567"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Request Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="date"
                  value={formData.requestDate}
                  onChange={(e) => setFormData({...formData, requestDate: e.target.value})}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Birth Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => setFormData({...formData, birthDate: e.target.value})}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Address
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <textarea
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  rows={3}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter customer address"
                />
              </div>
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Add any additional notes about the customer"
              />
            </div>
          </div>
        </div>

        {/* Comprehensive Measurements */}
        <div className="bg-white border rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
            <Plus className="h-5 w-5 mr-2 text-green-600" />
            Body Measurement Chart (inches)
          </h3>
          
          <div className="space-y-8">
            {measurementSections.map((section, sectionIndex) => (
              <div key={sectionIndex} className="border-l-4 border-blue-500 pl-6">
                <h4 className="text-md font-semibold text-gray-800 mb-4">{section.title}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {section.fields.map((field) => (
                    <div key={field.key}>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {field.label}
                      </label>
                      <input
                        type="number"
                        step="0.25"
                        value={measurements[field.key as keyof typeof measurements]}
                        onChange={(e) => setMeasurements({...measurements, [field.key]: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
                        placeholder="0.0"
                      />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-8 py-3 rounded-lg font-semibold flex items-center shadow-lg hover:shadow-xl transition-all"
          >
            <Save className="h-5 w-5 mr-2" />
            {loading ? 'Saving...' : 'Save Customer & Measurements'}
          </button>
        </div>
      </form>
    </div>
  );
}