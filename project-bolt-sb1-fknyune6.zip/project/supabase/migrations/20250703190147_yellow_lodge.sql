/*
  # Create customers and measurements tables

  1. New Tables
    - `customers`
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `email` (text, unique, required)
      - `phone` (text, required)
      - `address` (text)
      - `birth_date` (date)
      - `job_number` (text)
      - `request_date` (date)
      - `notes` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `owner_id` (uuid, foreign key to auth.users)
    
    - `measurements`
      - `id` (uuid, primary key)
      - `customer_id` (uuid, foreign key to customers)
      - All measurement fields (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `tailor_name` (text)
      - `measurement_notes` (text)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to manage their own data
*/

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  address text,
  birth_date date,
  job_number text,
  request_date date DEFAULT CURRENT_DATE,
  notes text,
  owner_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create measurements table
CREATE TABLE IF NOT EXISTS measurements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  
  -- Basic measurements
  height numeric(5,2),
  neck_width numeric(5,2),
  shoulder numeric(5,2),
  armhole_curve_upperarm_width numeric(5,2),
  chest numeric(5,2),
  underbust_nipple_to_nipple numeric(5,2),
  waist numeric(5,2),
  hips numeric(5,2),
  waist_to_knee_length numeric(5,2),
  waist_to_ankle numeric(5,2),
  thigh_circ numeric(5,2),
  ankle_circ numeric(5,2),
  shoulder_to_waist numeric(5,2),
  shoulder_to_ankle numeric(5,2),
  shoulder_to_wrist numeric(5,2),
  shoulder_to_elbow numeric(5,2),
  inner_arm_length numeric(5,2),
  outseam_length numeric(5,2),
  inseam_length numeric(5,2),
  back_rise numeric(5,2),
  front_rise numeric(5,2),
  
  -- Additional detailed measurements
  single_shoulder numeric(5,2),
  front_drop numeric(5,2),
  back_drop numeric(5,2),
  armhole_curve_straight numeric(5,2),
  neck_band_width numeric(5,2),
  collar_width numeric(5,2),
  collar_point numeric(5,2),
  sleeve_length numeric(5,2),
  sleeve_opening numeric(5,2),
  cuff_height numeric(5,2),
  waist_band numeric(5,2),
  leg_opening numeric(5,2),
  seat_length numeric(5,2),
  
  tailor_name text,
  measurement_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE measurements ENABLE ROW LEVEL SECURITY;

-- Create policies for customers table
CREATE POLICY "Users can manage their own customers"
  ON customers
  FOR ALL
  TO authenticated
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

-- Create policies for measurements table
CREATE POLICY "Users can manage measurements for their customers"
  ON measurements
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM customers 
      WHERE customers.id = measurements.customer_id 
      AND customers.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM customers 
      WHERE customers.id = measurements.customer_id 
      AND customers.owner_id = auth.uid()
    )
  );

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_customers_updated_at 
  BEFORE UPDATE ON customers 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_measurements_updated_at 
  BEFORE UPDATE ON measurements 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();